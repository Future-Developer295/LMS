create database ERP_SYSTEM

use ERP_SYSTEM

create table roles(
role_id int primary key identity(1,1),
role_name varchar(100),
description text
)


create table permissions(
permission_id int primary key identity(1,1),
role_id int,
permission_name varchar(100),
description text,
foreign key (role_id) references roles(role_id)
)


create table Users(
user_id int primary key identity(1,1),
role_id int,
username varchar(100),
email varchar(100),
password varchar(100),
status tinyint ,
created_at TIMESTAMP ,
foreign key (role_id) references roles(role_id)
)


create table departments(
department_id int primary key identity(1,1),
department_name  varchar(100),
description text
)


create table Employees(
employee_id int primary key identity(1,1),
department_id int,
employee_code int,
first_name varchar(100),
last_name varchar(100),
gender TINYINT,
date_of_birth date,
phone int,
email varchar(100),
address text,
hire_date date,
job_title  varchar(100),
salary int,
status TINYINT,
foreign key (department_id) references departments(department_id)
)


CREATE TABLE attendance (
attendance_id int primary key identity(1,1),
employee_id int,
attendance_date DATE,
check_in DATETIME,
check_out DATETIME,
status tinyint,
remarks VARCHAR(250),
foreign key (employee_id) references Employees(employee_id)
)


create table leaves(
leave_id int primary key identity(1,1),
employee_id int,
leave_type varchar(100),
start_date date,
end_date date,
reason text,
status tinyint,
approved_by int,
foreign key (employee_id) references Employees(employee_id)
)


create table payroll(
payroll_id int primary key identity(1,1),
employee_id int,
salary_month date,
basic_salary int,
allowances int,
deductions int,
net_salary int,
payment_status tinyint,
payment_date date,
foreign key (employee_id) references Employees(employee_id)
)


create table categories(
category_id int primary key identity(1,1),
category_name varchar(100),
description text,
status tinyint
)


create table Products(
product_id int primary key identity(1,1),
category_id int,
product_code varchar(50),
product_name varchar(150),
description text,
unit_price int,
cost_price int,
unit int,
reorder_level int,
status tinyint,
foreign key (category_id) references categories(category_id)
)


create table warehouses(
warehouse_id int primary key identity(1,1),
warehouse_name varchar(100),
location varchar(max),
manager_name varchar(100),
phone varchar(20),
status tinyint
)


create table stock(
stock_id int primary key identity(1,1),
product_id int,
warehouse_id int,
quantity int,
reserved_quantity int,
last_updated DATETIME,
foreign key (product_id) references Products(product_id),
foreign key (warehouse_id) references warehouses(warehouse_id)
)


create table stock_movements(
movement_id int primary key identity(1,1),
product_id int,
warehouse_id int,
movement_type varchar(100),
quantity int,
reference_type varchar(100),
reference_id int,
movement_date date,
remarks varchar(max),
foreign key (product_id) references Products(product_id),
foreign key (warehouse_id) references warehouses(warehouse_id)
)


create table custumers(
customer_id int primary key identity(1,1),
customer_code varchar(20),
customer_name varchar(100),
phone varchar(20),
email varchar(50),
address varchar(max),
city varchar(100),
credit_limit int,
status tinyint
)

create table sales_orders(
order_id int primary key identity(1,1),
customer_id int,
order_date date,
total_amount int,
discount int,
tax int,
net_amount int,
status tinyint,
foreign key (customer_id) references custumers(customer_id)
)


create table sales_order_items(
order_item_id int primary key identity(1,1),
order_id int,
product_id int,
quantity int,
unit_price int,
discount int,
total_price int,
foreign key (order_id) references sales_orders(order_id),
foreign key (product_id) references products(product_id)
)


create table sales_invoices(
invoice_id int primary key identity(1,1),
order_id int,
customer_id int,
invoice_number int,
invoice_date date,
due_date date,
total_amount int,
tax int,
discount int,
net_amount int,
payment_status tinyint,
foreign key (order_id) references sales_orders(order_id),
foreign key (customer_id) references custumers(customer_id)
)


create table Suppliers(
supplier_id int primary key identity(1,1),
supplier_code varchar(20),
supplier_name varchar(100),
contact_person varchar(20),
email varchar(50),
address varchar(max),
city varchar(100),
status tinyint
)


create table purchase_orders(
purchase_order_id int primary key identity(1,1),
supplier_id int,
order_date date,
expected_date date,
total_amount int,
tax int,
discount int,
net_amount int,
status tinyint,
foreign key (supplier_id) references Suppliers(supplier_id)
)


create table purchase_order_items(
purchase_item_id int primary key identity(1,1),
purchase_order_id int,
product_id int,
quantity int,
unit_cost int,
total_cost int,
foreign key (purchase_order_id) references purchase_orders(purchase_order_id),
foreign key (product_id) references products(product_id)
)


create table purchase_invoices(
purchase_invoice_id int primary key identity(1,1),
purchase_order_id int,
supplier_id int,
invoice_number int,
invoice_date date,
due_date date,
total_amount int,
tax int,
discount int,
net_amount int,
payment_status tinyint,
foreign key (purchase_order_id) references purchase_orders(purchase_order_id),
foreign key (supplier_id) references Suppliers(supplier_id)
)


create table Accounts(
account_id int primary key identity(1,1),
account_code varchar(20),
account_name varchar(100),
account_type varchar(20),
parent_account_id int,
balance int,
status tinyint
) 


create table payments(
payment_id int primary key identity(1,1),
customer_id int,
supplier_id int,
invoice_id int,
amount int,
payment_method int,
payment_date date,
reference_number varchar(20),
remarks varchar(max),
foreign key (customer_id) references custumers(customer_id),
foreign key (supplier_id) references Suppliers(supplier_id),
foreign key (invoice_id) references sales_invoices(invoice_id)
)


create table expenses(
expense_id int primary key identity(1,1),
account_id int,
employee_id int,
expense_date date,
expense_type varchar(100),
amount int,
description varchar(max),
payment_method varchar(20),
status tinyint,
foreign key (account_id) references Accounts(account_id)
)

create table transactions(
transaction_id int primary key identity(1,1),
account_id int,
transaction_type int,
amount int,
transaction_date date,
reference_type int,
reference_id int,
description varchar(max),
foreign key (account_id) references Accounts(account_id)
)


create table Company(
company_id int primary key identity(1,1),
company_name varchar(100),
registration_number int,
phone varchar(20),
email varchar(20),
address varchar(max),
city varchar(50),
country varchar(50),
tax_number int,
created_at datetime
)  


create table audit_logs(
log_id int primary key identity(1,1),
user_id int,
table_name varchar(100),
record_id varchar(100),
old_values int,
new_values int,
ip_address varchar(100),
created_at datetime,
foreign key (user_id) references users(user_id)
)